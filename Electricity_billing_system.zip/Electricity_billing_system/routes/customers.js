const express = require("express");
const db = require("../models/db");

const app = express();
app.use(express.json());

const customers = express.Router();

// Customer Routes
customers.get("/cust", (req, res) => {
    db.query("SELECT * FROM customers", (err, results) => {
        if (err) {
            return res.status(500).json({ message: "Database query failed", error: err.message });
        }
        res.status(200).json(results);
    });
});

// POST /cust
customers.post("/cust", (req, res) => {
    const { name, email, address } = req.body;

    if (!name || !email || !address) {
        return res.status(400).json({ message: "Missing required fields: name, email, address" });
    }

    db.query(
        "INSERT INTO customers (name, email, address) VALUES (?, ?, ?)",
        [name, email, address],
        (err, results) => {
            if (err) {
                return res.status(500).json({ message: "Failed to insert customer", error: err.message });
            }
            res.status(201).json({ message: "Customer added successfully", customerId: results.insertId });
        }
    );
});

module.exports = customers;
