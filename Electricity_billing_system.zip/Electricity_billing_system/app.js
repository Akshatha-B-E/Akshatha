
const express = require("express");
const cors = require('cors');
const customers = require("./routes/customers");
const  bills = require("./routes/bills");

const app = express();
app.use(cors());

app.use(express.json());


let customer = [];
let bils = [];

// Use the routes
app.use("/api", customers);
app.use("/api", bills);

const PORT = 3033;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
