const express = require("express");
const db = require("../models/db");
const Joi = require("joi");  // Adding Joi for validation

// Middleware to parse JSON data
const bills = express.Router();

// Bill validation schema
const billSchema = Joi.object({
    customer_id: Joi.number().integer().required(),
    units: Joi.number().integer().positive().required(),
});

// Bill Routes
bills.get("/bills", (req, res) => {
    const query = `
        SELECT b.id, c.name AS customer_name, b.units_consumed, b.amount, b.billing_date
        FROM bills b 
        JOIN customers c ON b.customer_id = c.id
    `;
    db.query(query, (err, results) => {
        if (err) {
            console.error(err); // Log the error for debugging
            return res.status(500).json({ message: "Failed to fetch bills", error: err.message });
        }
        res.status(200).json(results);
    });
});

bills.post("/bills", (req, res) => {
    const { customer_id, units } = req.body;

    // Validate request body with Joi
    const { error } = billSchema.validate({ customer_id, units });
    if (error) {
        return res.status(400).json({ message: "Validation error", details: error.details });
    }

    const amount = units * 5; // Assuming rate is 5 per unit
    const billing_date = new Date().toISOString().split("T")[0];

    db.query(
        "INSERT INTO bills (customer_id, units_consumed, amount, billing_date) VALUES (?, ?, ?, ?)",
        [customer_id, units, amount, billing_date],
        (err, results) => {
            if (err) {
                console.error(err); // Log the error for debugging
                return res.status(500).json({ message: "Failed to create bill", error: err.message });
            }
            res.status(201).json({ message: "Bill created successfully", billId: results.insertId });
        }
    );
});

// Export the routes
module.exports = bills;
