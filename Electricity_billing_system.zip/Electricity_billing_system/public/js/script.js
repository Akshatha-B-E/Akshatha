document.addEventListener("DOMContentLoaded", () => {
    const customerForm = document.getElementById("customerForm");
    const billForm = document.getElementById("billForm");
    const customerSelect = document.getElementById("customerSelect");
    const billTable = document.getElementById("billTable");

    const API_URL = "http://localhost:3033";


    

    const fetchCustomers = async () => { 
        try {
            const res = await fetch(`${API_URL}/api/cust`);
            const customers = await res.json();
            console.log(customers);
            customerSelect.innerHTML = customers.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
        }
        catch (error) {
            console.log('Error fetching customers:', error);
        }
    };

    const fetchBills = async () => {
        try {
            const res = await fetch(`${API_URL}/api/bills`);
            const bills = await res.json();
            console.log(bills);
            billTable.innerHTML = bills.map(b => `
                <tr>
                    <td>${b.id}</td>
                    <td>${b.customer_name}</td>
                    <td>${b.units_consumed}</td>
                    <td>${b.amount}</td>
                    <td>${b.billing_date}</td>
                </tr>
            `).join("");
        }
        catch (error) {
            console.log('Error fetching bills:', error);
        }
    };

    customerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        alert("Customer form submitted");
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const address = document.getElementById("address").value;

        await fetch(`${API_URL}/api/cust`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, address }),
        });

        customerForm.reset();
        fetchCustomers();
    });

    billForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        alert("Bill generated");
        const customerId = customerSelect.value;
        const units = document.getElementById("units").value;

        await fetch(`${API_URL}/api/bills`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ customer_id: customerId, units }),
        });

        billForm.reset();
        fetchBills();
    });

    fetchCustomers();
    fetchBills();
});
